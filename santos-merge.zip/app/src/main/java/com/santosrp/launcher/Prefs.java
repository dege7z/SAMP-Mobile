package com.santosrp.launcher;

import android.content.Context;
import android.content.SharedPreferences;

public final class Prefs {
    private Prefs() {}

    private static SharedPreferences sp(Context c) {
        return c.getSharedPreferences("santos_prefs", Context.MODE_PRIVATE);
    }

    public static String getNick(Context c) {
        return sp(c).getString("nick", "");
    }

    public static void setNick(Context c, String nick) {
        sp(c).edit().putString("nick", nick).apply();
    }

    public static void clearNick(Context c) {
        sp(c).edit().remove("nick").apply();
    }
}
