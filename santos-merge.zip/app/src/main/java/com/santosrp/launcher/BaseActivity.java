package com.santosrp.launcher;

import androidx.appcompat.app.AppCompatActivity;

/** Mantém o app em tela cheia (esconde barras do sistema). */
public class BaseActivity extends AppCompatActivity {
    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) UiUtils.immersive(this);
    }
}
