package com.santosrp.launcher;

import com.gta.game.R;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.Html;
import android.text.InputType;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;

import java.util.regex.Pattern;

public class LoginActivity extends BaseActivity {

    // Regra padrão de nick do SA-MP: 3 a 20 caracteres
    private static final Pattern NICK = Pattern.compile("^[a-zA-Z0-9\\[\\]\\(\\)\\$@\\._=]{3,20}$");

    private CheckBox cbTerms;

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) FullScreen.hideBars(this);
    }

    @SuppressWarnings("deprecation")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        cbTerms = findViewById(R.id.cbTerms);
        TextView tvTerms = findViewById(R.id.tvTerms);
        View btnGoogle = findViewById(R.id.btnGoogle);
        View chipLang = findViewById(R.id.chipLang);

        tvTerms.setText(Html.fromHtml("Eu concordo com os <u>Termos</u> e a <u>Política de Privacidade</u>."));

        View loginRoot = findViewById(R.id.root);
        Glass.apply(loginRoot, findViewById(R.id.termsBox), 14);
        Glass.apply(loginRoot, chipLang, 14);
        FullScreen.padContentForCutout(loginRoot, findViewById(R.id.content));

        UiUtils.pressEffect(btnGoogle);
        UiUtils.pressEffect(chipLang);
        UiUtils.staggerIn(new View[]{findViewById(R.id.leftCol)}, -80f);

        tvTerms.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Config.TERMS_URL.isEmpty()) {
                    toast("Link dos termos ainda não configurado.");
                } else {
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(Config.TERMS_URL)));
                }
            }
        });

        chipLang.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                toast("Outros idiomas em breve");
            }
        });

        btnGoogle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!cbTerms.isChecked()) {
                    toast("Aceite os termos para continuar.");
                    return;
                }
                showNickDialog();
            }
        });
    }

    /** Provisório: o login real com Google entra depois. Por enquanto pede só o nick. */
    private void showNickDialog() {
        final EditText et = new EditText(this);
        et.setHint("Ex: Joao_Silva");
        et.setSingleLine(true);
        et.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);

        float d = getResources().getDisplayMetrics().density;
        FrameLayout box = new FrameLayout(this);
        box.setPadding((int) (22 * d), (int) (8 * d), (int) (22 * d), 0);
        box.addView(et);

        final AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Escolha seu nick")
                .setMessage("O login real com Google vem depois. Por enquanto, entre com um nick.")
                .setView(box)
                .setPositiveButton("Entrar", null)
                .setNegativeButton("Cancelar", null)
                .create();
        dialog.show();

        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String nick = et.getText().toString().trim();
                if (!NICK.matcher(nick).matches()) {
                    et.setError("3 a 20 caracteres: letras, números e _ . [ ] ( ) $ @ =");
                    return;
                }
                dialog.dismiss();
                Prefs.setNick(LoginActivity.this, nick);
                startActivity(new Intent(LoginActivity.this, MainActivity.class));
                overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
                finish();
            }
        });
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }
}
