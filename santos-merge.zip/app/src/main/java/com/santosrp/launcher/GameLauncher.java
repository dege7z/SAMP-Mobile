package com.santosrp.launcher;

import android.Manifest;
import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.Settings;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.util.ArrayList;
import java.util.List;

/**
 * Prepara e abre o cliente SA-MP (com.gta.game).
 * O cliente lê nick/IP/porta de /storage/emulated/0/GTA/SAMP/settings.ini ao iniciar,
 * então o launcher grava esse arquivo e chama a activity do jogo.
 */
public final class GameLauncher {
    private GameLauncher() {}

    private static final String INI_PATH = Config.GAME_DIR + "SAMP/settings.ini";

    // ------------------------------------------------------------ permissões

    public static boolean hasStorageAccess(Context c) {
        if (Build.VERSION.SDK_INT >= 30) return Environment.isExternalStorageManager();
        return ContextCompat.checkSelfPermission(c, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                == PackageManager.PERMISSION_GRANTED;
    }

    public static void requestStorageAccess(Activity a) {
        if (Build.VERSION.SDK_INT >= 30) {
            try {
                a.startActivity(new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                        Uri.parse("package:" + a.getPackageName())));
            } catch (Exception e) {
                try {
                    a.startActivity(new Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION));
                } catch (Exception ignored) {}
            }
        } else {
            ActivityCompat.requestPermissions(a, new String[]{
                    Manifest.permission.WRITE_EXTERNAL_STORAGE,
                    Manifest.permission.READ_EXTERNAL_STORAGE}, 1001);
        }
    }

    // ---------------------------------------------------------------- cliente

    public static boolean isGameInstalled(Context c) {
        return true; // cliente e launcher agora são o mesmo app
    }

    /** Nick no formato aceito pelo SA-MP: letras, números e ] [ ( ) $ @ . _ = ; até 24. */
    public static String sanitizeNick(String raw) {
        StringBuilder sb = new StringBuilder();
        if (raw != null) {
            String allowed = "[]()$@._=";
            for (int i = 0; i < raw.length() && sb.length() < 24; i++) {
                char ch = raw.charAt(i);
                if (ch == ' ') ch = '_';
                boolean ok = (ch >= 'a' && ch <= 'z') || (ch >= 'A' && ch <= 'Z')
                        || (ch >= '0' && ch <= '9') || allowed.indexOf(ch) >= 0;
                if (ok) sb.append(ch);
            }
        }
        if (sb.length() < 3) sb.append("Jogador").append(100 + (int) (Math.random() * 900));
        return sb.toString();
    }

    /** Atualiza name/host/port na seção [client], preservando o resto do arquivo. */
    public static void writeSettings(String nick, String host, int port) throws IOException {
        File ini = new File(INI_PATH);
        File dir = ini.getParentFile();
        if (dir != null && !dir.exists() && !dir.mkdirs()) {
            throw new IOException("Não consegui criar a pasta " + dir.getPath());
        }

        List<String> lines = new ArrayList<>();
        if (ini.exists()) {
            try (BufferedReader r = new BufferedReader(
                    new InputStreamReader(new FileInputStream(ini), "UTF-8"))) {
                String s;
                while ((s = r.readLine()) != null) lines.add(s);
            }
        }

        int start = -1, end = -1;
        for (int i = 0; i < lines.size(); i++) {
            String t = lines.get(i).trim();
            if (t.startsWith("[") && t.endsWith("]")) {
                if (start < 0 && t.equalsIgnoreCase("[client]")) start = i;
                else if (start >= 0 && end < 0) end = i;
            }
        }
        if (start < 0) {
            lines.add(0, "[client]");
            start = 0;
            end = 1;
        } else if (end < 0) {
            end = lines.size();
        }

        String[][] kv = {{"name", nick}, {"host", host}, {"port", String.valueOf(port)}};
        for (String[] p : kv) {
            boolean done = false;
            for (int i = start + 1; i < end; i++) {
                String t = lines.get(i).trim();
                if (t.startsWith(";") || t.startsWith("#")) continue;
                int eq = t.indexOf('=');
                if (eq > 0 && t.substring(0, eq).trim().equalsIgnoreCase(p[0])) {
                    lines.set(i, p[0] + "=" + p[1]);
                    done = true;
                    break;
                }
            }
            if (!done) {
                lines.add(end, p[0] + "=" + p[1]);
                end++;
            }
        }

        try (Writer w = new OutputStreamWriter(new FileOutputStream(ini), "UTF-8")) {
            for (String l : lines) w.write(l + "\n");
        }
    }

    public static void launch(Activity a) {
        Intent i = new Intent(a, com.gta.game.SAMP.class);
        a.startActivity(i);
    }
}
