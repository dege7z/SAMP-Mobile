package com.santosrp.launcher;

import com.gta.game.R;

import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.view.View;
import android.view.ViewTreeObserver;

/**
 * Vidro fosco: cada painel mostra um pedaço DESFOCADO da própria foto de fundo
 * (sem degradê), mais uma película translúcida e um fio branco bem fino.
 */
public final class Glass {
    private Glass() {}

    /** Quanto o fundo é escurecido (igual ao scrim das telas). */
    public static final int SCRIM = 0x66000000;
    public static final int TINT = 0x1AFFFFFF;
    public static final int STROKE = 0x33FFFFFF;

    private static Bitmap blurred;
    private static boolean blurFailed = false;

    /** Devolve a foto desfocada, ou null se faltar memória (o painel então só usa a película). */
    private static synchronized Bitmap blurredBg(Resources res) {
        if (blurred == null && !blurFailed) {
            try {
                BitmapFactory.Options o = new BitmapFactory.Options();
                o.inSampleSize = 8; // ~240x135: já é bem suave e leve
                Bitmap src = BitmapFactory.decodeResource(res, R.drawable.bg_santos, o);
                if (src == null) {
                    blurFailed = true;
                } else {
                    blurred = boxBlur(src, 3, 3);
                }
            } catch (Throwable t) { // OutOfMemoryError etc.
                blurFailed = true;
            }
        }
        return blurred;
    }

    private static Bitmap boxBlur(Bitmap src, int radius, int passes) {
        int w = src.getWidth(), h = src.getHeight();
        int[] px = new int[w * h];
        src.getPixels(px, 0, w, 0, 0, w, h);
        int[] tmp = new int[w * h];
        for (int i = 0; i < passes; i++) {
            blurLine(px, tmp, w, h, radius, true);
            blurLine(tmp, px, w, h, radius, false);
        }
        Bitmap out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        out.setPixels(px, 0, w, 0, 0, w, h);
        return out;
    }

    private static void blurLine(int[] in, int[] out, int w, int h, int r, boolean horiz) {
        int lines = horiz ? h : w, len = horiz ? w : h;
        for (int l = 0; l < lines; l++) {
            for (int i = 0; i < len; i++) {
                int a = 0, rr = 0, g = 0, b = 0, n = 0;
                for (int k = -r; k <= r; k++) {
                    int j = i + k;
                    if (j < 0) j = 0; else if (j >= len) j = len - 1;
                    int p = horiz ? in[l * w + j] : in[j * w + l];
                    a += p >>> 24; rr += (p >> 16) & 255; g += (p >> 8) & 255; b += p & 255; n++;
                }
                int v = ((a / n) << 24) | ((rr / n) << 16) | ((g / n) << 8) | (b / n);
                if (horiz) out[l * w + i] = v; else out[i * w + l] = v;
            }
        }
    }

    public static void apply(View root, View v, float radiusDp) {
        apply(root, v, radiusDp, TINT, STROKE);
    }

    public static void apply(final View root, final View v, float radiusDp, int tint, int stroke) {
        float d = v.getResources().getDisplayMetrics().density;
        final GlassDrawable g = new GlassDrawable(root, v, radiusDp * d, d, tint, stroke);
        v.setBackground(g);
        // acompanha o painel enquanto ele desliza na animação de entrada
        v.getViewTreeObserver().addOnPreDrawListener(new ViewTreeObserver.OnPreDrawListener() {
            @Override
            public boolean onPreDraw() {
                if (g.moved()) v.invalidate();
                return true;
            }
        });
    }

    private static final class GlassDrawable extends Drawable {
        private final View root, view;
        private final float radius, density;
        private final int tint, stroke;
        private final Paint bmpPaint = new Paint(Paint.FILTER_BITMAP_FLAG | Paint.ANTI_ALIAS_FLAG);
        private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Matrix m = new Matrix();
        private final Path clip = new Path();
        private final int[] loc = new int[2], rootLoc = new int[2];
        private int lastX = Integer.MIN_VALUE, lastY = Integer.MIN_VALUE;

        GlassDrawable(View root, View view, float radius, float density, int tint, int stroke) {
            this.root = root; this.view = view; this.radius = radius; this.density = density;
            this.tint = tint; this.stroke = stroke;
            line.setStyle(Paint.Style.STROKE);
            line.setStrokeWidth(density);
        }

        boolean moved() {
            view.getLocationInWindow(loc);
            return loc[0] != lastX || loc[1] != lastY;
        }

        @Override
        public void draw(Canvas c) {
            RectF b = new RectF(getBounds());
            clip.reset();
            clip.addRoundRect(b, radius, radius, Path.Direction.CW);

            view.getLocationInWindow(loc);
            root.getLocationInWindow(rootLoc);
            lastX = loc[0]; lastY = loc[1];

            int rw = root.getWidth(), rh = root.getHeight();
            Bitmap bmp = blurredBg(view.getResources());
            c.save();
            c.clipPath(clip);
            if (bmp != null && rw > 0 && rh > 0) {
                // mesma conta do centerCrop da foto de fundo
                float s = Math.max(rw / (float) bmp.getWidth(), rh / (float) bmp.getHeight());
                float dx = (rw - bmp.getWidth() * s) / 2f, dy = (rh - bmp.getHeight() * s) / 2f;
                m.reset();
                m.postScale(s, s);
                m.postTranslate(dx - (loc[0] - rootLoc[0]), dy - (loc[1] - rootLoc[1]));
                c.drawBitmap(bmp, m, bmpPaint);
            }
            fill.setColor(SCRIM);
            c.drawPath(clip, fill);
            fill.setColor(tint);
            c.drawPath(clip, fill);
            c.restore();

            line.setColor(stroke);
            float h = density / 2f;
            c.drawRoundRect(new RectF(b.left + h, b.top + h, b.right - h, b.bottom - h), radius, radius, line);
        }

        @Override public void setAlpha(int a) {}
        @Override public void setColorFilter(ColorFilter f) {}
        @Override public int getOpacity() { return PixelFormat.TRANSLUCENT; }
    }
}
