package com.santosrp.launcher;

import com.gta.game.R;

import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends BaseActivity {

    private final java.util.ArrayList<ObjectAnimator> anims = new java.util.ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        String nick = Prefs.getNick(this);
        if (nick.isEmpty()) {
            startActivity(new Intent(this, LoginActivity.class));
            finish();
            return;
        }

        setContentView(R.layout.activity_main);

        TextView tvAvatar = findViewById(R.id.tvAvatar);
        TextView tvNick = findViewById(R.id.tvNick);
        TextView tvOnline = findViewById(R.id.tvOnline);
        TextView tvPlayers = findViewById(R.id.tvPlayers);
        TextView tvServerName = findViewById(R.id.tvServerName);
        ProgressBar barPlayers = findViewById(R.id.barPlayers);
        View btnPlay = findViewById(R.id.btnPlay);
        // Texto do botão mais gordinho: contorno fino da mesma cor engrossa as letras
        TextView tvPlay = findViewById(R.id.tvPlay);
        tvPlay.getPaint().setStyle(android.graphics.Paint.Style.FILL_AND_STROKE);
        tvPlay.getPaint().setStrokeWidth(0.7f * getResources().getDisplayMetrics().density);
        tvPlay.getPaint().setStrokeJoin(android.graphics.Paint.Join.ROUND);

        tvNick.setText(nick);
        tvAvatar.setText(nick.substring(0, 1).toUpperCase());
        tvServerName.setText(Config.SERVER_NAME);

        // Ainda sem consulta ao servidor: mostra traços até a próxima etapa.
        tvOnline.setText("—");
        tvPlayers.setText("— / —");
        barPlayers.setProgress(0);
        refreshPlayers(tvOnline, tvPlayers, barPlayers);

        View root = findViewById(R.id.root);
        Glass.apply(root, findViewById(R.id.profilePill), 14);
        Glass.apply(root, findViewById(R.id.leftCol), 12);
        Glass.apply(root, findViewById(R.id.cardServer), 14);
        Glass.apply(root, findViewById(R.id.onlinePill), 50);

        FullScreen.padContentForCutout(findViewById(R.id.root), findViewById(R.id.content));

        View profile = findViewById(R.id.profilePill);
        View cardServer = findViewById(R.id.cardServer);
        View btnDiscord = findViewById(R.id.btnDiscord);
        View btnInstagram = findViewById(R.id.btnInstagram);
        View btnYoutube = findViewById(R.id.btnYoutube);

        for (View v : new View[]{profile, cardServer, btnPlay, btnDiscord, btnInstagram, btnYoutube}) {
            UiUtils.pressEffect(v);
        }

        UiUtils.staggerIn(new View[]{findViewById(R.id.leftCol)}, -70f);
        UiUtils.staggerIn(new View[]{findViewById(R.id.rightCol)}, 70f);

        btnPlay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Config.SERVER_IP.isEmpty()) {
                    toast("O IP do servidor ainda não foi configurado.");
                } else if (!GameLauncher.hasStorageAccess(MainActivity.this)) {
                    toast("Permita o acesso aos arquivos e toque em JOGAR de novo.");
                    GameLauncher.requestStorageAccess(MainActivity.this);
                } else if (!GameLauncher.isGameInstalled(MainActivity.this)) {
                    toast("Instale o cliente do jogo (" + Config.GAME_PACKAGE + ") primeiro.");
                } else if (Config.CACHE_ENABLED && !CacheDownloader.isInstalled(MainActivity.this)) {
                    if (Config.CACHE_URL.isEmpty()) {
                        toast("O link do cache ainda não foi configurado.");
                    } else if (cacheDialog == null || !cacheDialog.isShowing()) {
                        cacheDialog = CacheDialog.show(MainActivity.this, new CacheDialog.OnFinish() {
                            @Override public void onInstalled() { openGame(); }
                        });
                    }
                } else {
                    openGame();
                }
            }
        });

        cardServer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                toast("Só há um servidor por enquanto.");
            }
        });

        btnDiscord.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openUrl(Config.DISCORD_URL, "Link do Discord ainda não configurado.");
            }
        });

        btnInstagram.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openUrl(Config.INSTAGRAM_URL, "Link do Instagram ainda não configurado.");
            }
        });

        btnYoutube.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openUrl(Config.YOUTUBE_URL, "Link do YouTube ainda não configurado.");
            }
        });

        // Perfil = trocar de conta
        profile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Prefs.clearNick(MainActivity.this);
                startActivity(new Intent(MainActivity.this, LoginActivity.class));
                overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
                finish();
            }
        });
    }

    private volatile boolean destroyed = false;
    private android.app.Dialog cacheDialog;

    /** Soma os jogadores de todos os servidores (e mostra o primeiro no card). */
    private void refreshPlayers(final TextView tvOnline, final TextView tvPlayers, final ProgressBar bar) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                int total = 0;
                boolean any = false;
                int[] first = null;
                for (int i = 0; i < Config.SERVERS.length; i++) {
                    String[] s = Config.SERVERS[i];
                    int port = 7777;
                    try { port = Integer.parseInt(s[1]); } catch (Exception ignored) {}
                    int[] r = ServerQuery.query(s[0], port);
                    if (r != null) {
                        any = true;
                        total += r[0];
                        if (first == null) first = r;
                    }
                }
                final boolean ok = any;
                final int sum = total;
                final int[] f = first;
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (destroyed) return;
                        tvOnline.setText(ok ? java.text.NumberFormat.getInstance(new java.util.Locale("pt","BR")).format(sum) : "—");
                        if (f != null) {
                            tvPlayers.setText(f[0] + " / " + f[1]);
                            bar.setProgress(f[1] > 0 ? f[0] * 100 / f[1] : 0);
                        }
                    }
                });
                // atualiza de novo em 30 s enquanto a tela estiver aberta
                if (!destroyed) {
                    try { Thread.sleep(30000); } catch (InterruptedException e) { return; }
                    if (!destroyed) refreshPlayers(tvOnline, tvPlayers, bar);
                }
            }
        }).start();
    }

    @Override
    protected void onDestroy() {
        destroyed = true;
        if (cacheDialog != null && cacheDialog.isShowing()) cacheDialog.dismiss();
        for (ObjectAnimator a : anims) a.cancel();
        anims.clear();
        super.onDestroy();
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) FullScreen.hideBars(this);
    }

    /** Grava nick/IP/porta no settings.ini do cliente e abre o jogo já conectando no servidor. */
    private void openGame() {
        try {
            String nick = GameLauncher.sanitizeNick(Prefs.getNick(this));
            GameLauncher.writeSettings(nick, Config.SERVER_IP, Config.SERVER_PORT);
            GameLauncher.launch(this);
        } catch (Exception e) {
            toast("Não consegui abrir o jogo: " + e.getMessage());
        }
    }

    private void openUrl(String url, String emptyMsg) {
        if (url.isEmpty()) {
            toast(emptyMsg);
            return;
        }
        startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }
}
