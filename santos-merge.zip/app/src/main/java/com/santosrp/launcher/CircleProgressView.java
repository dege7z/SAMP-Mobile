package com.santosrp.launcher;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.view.View;

/** Círculo de progresso: anel escuro + arco vermelho com ponta redonda e brilho, % no centro. */
public class CircleProgressView extends View {

    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint track = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint glow = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint arc = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF box = new RectF();
    private int progress = 0;

    public CircleProgressView(Context c) { super(c); init(); }
    public CircleProgressView(Context c, AttributeSet a) { super(c, a); init(); }

    private void init() {
        float d = getResources().getDisplayMetrics().density;
        setLayerType(LAYER_TYPE_SOFTWARE, null);

        fill.setStyle(Paint.Style.FILL);
        fill.setColor(0x66000000);

        track.setStyle(Paint.Style.STROKE);
        track.setStrokeWidth(7f * d);
        track.setColor(0x33FFFFFF);

        arc.setStyle(Paint.Style.STROKE);
        arc.setStrokeWidth(7f * d);
        arc.setStrokeCap(Paint.Cap.ROUND);
        arc.setColor(0xFFFF1A1A);

        glow.setStyle(Paint.Style.STROKE);
        glow.setStrokeWidth(7f * d);
        glow.setStrokeCap(Paint.Cap.ROUND);
        glow.setColor(0xFFFF1A1A);
        glow.setMaskFilter(new android.graphics.BlurMaskFilter(6f * d, android.graphics.BlurMaskFilter.Blur.NORMAL));

        text.setColor(0xFFFFFFFF);
        text.setTextAlign(Paint.Align.CENTER);
        text.setTypeface(Typeface.create("sans-serif-black", Typeface.NORMAL));
        text.setTextSize(15f * d);
    }

    public void setProgress(int p) {
        progress = Math.max(0, Math.min(100, p));
        invalidate();
    }

    @Override
    protected void onDraw(Canvas c) {
        float d = getResources().getDisplayMetrics().density;
        float pad = 11f * d;
        float cx = getWidth() / 2f, cy = getHeight() / 2f;
        float r = Math.min(getWidth(), getHeight()) / 2f - pad;
        box.set(cx - r, cy - r, cx + r, cy + r);

        c.drawCircle(cx, cy, r, fill);
        c.drawCircle(cx, cy, r, track);
        if (progress > 0) {
            float sweep = 360f * progress / 100f;
            c.drawArc(box, -90f, sweep, false, glow);
            c.drawArc(box, -90f, sweep, false, arc);
        }
        float ty = cy - (text.descent() + text.ascent()) / 2f;
        c.drawText(progress + "%", cx, ty, text);
    }
}
