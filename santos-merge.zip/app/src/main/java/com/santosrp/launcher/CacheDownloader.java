package com.santosrp.launcher;

import android.content.Context;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Enumeration;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

/**
 * Baixa o cache (.zip) e extrai em Android/data/<pacote>/files.
 * - Retoma o download de onde parou (arquivo .part + header Range).
 * - Confere espaço livre antes de começar.
 * - Extração protegida contra caminhos maliciosos dentro do zip (zip-slip).
 */
public final class CacheDownloader {

    public interface Listener {
        /** Chamado da thread de download: use runOnUiThread/Handler para mexer na tela. */
        void onProgress(String fase, int percent, long feito, long total);
        void onDone();
        void onError(String mensagem);
    }

    private static final String MARKER = ".santos_cache";
    private volatile boolean cancelled = false;

    public static File dir(Context c) {
        File d = new File(Config.GAME_DIR);
        if (!d.exists()) d.mkdirs();
        if (d.exists() && d.canWrite()) return d;
        File e = c.getExternalFilesDir(null);
        return e != null ? e : c.getFilesDir();
    }

    /** True se o cache da versão atual (Config.CACHE_VERSION) já foi instalado. */
    public static boolean isInstalled(Context c) {
        File m = new File(dir(c), MARKER);
        if (!m.exists()) return false;
        try (java.io.BufferedReader r = new java.io.BufferedReader(new java.io.FileReader(m))) {
            String v = r.readLine();
            return v != null && v.trim().equals(Config.CACHE_VERSION);
        } catch (IOException e) {
            return false;
        }
    }

    public void cancel() { cancelled = true; }

    public void start(final Context ctx, final Listener l) {
        final Context app = ctx.getApplicationContext();
        new Thread(new Runnable() {
            @Override public void run() {
                try {
                    File base = dir(app);
                    if (!base.exists()) base.mkdirs();
                    File part = new File(base, "cache.zip.part");
                    File zip = new File(base, "cache.zip");

                    if (!zip.exists()) {
                        if (!download(base, part, l)) return;      // cancelado
                        if (!part.renameTo(zip)) throw new IOException("Não consegui finalizar o arquivo baixado.");
                    }
                    if (!extract(base, zip, l)) return;            // cancelado
                    zip.delete();

                    try (OutputStream o = new FileOutputStream(new File(base, MARKER))) {
                        o.write(Config.CACHE_VERSION.getBytes("UTF-8"));
                    }
                    l.onDone();
                } catch (Exception e) {
                    String m = e.getMessage();
                    l.onError(m == null || m.isEmpty() ? e.getClass().getSimpleName() : m);
                }
            }
        }).start();
    }

    // ---------------------------------------------------------------- download

    private boolean download(File base, File part, Listener l) throws IOException {
        long existing = part.exists() ? part.length() : 0;
        HttpURLConnection con = open(Config.CACHE_URL, existing);
        int code = con.getResponseCode();

        if (code == 416 && existing > 0) {          // já estava completo
            con.disconnect();
            return true;
        }
        if (code != 200 && code != 206) {
            con.disconnect();
            throw new IOException("Servidor do cache respondeu com erro " + code + ".");
        }
        boolean resume = (code == 206);
        if (!resume) existing = 0;                  // servidor ignorou o Range: recomeça

        long len = -1;
        try { len = Long.parseLong(con.getHeaderField("Content-Length")); } catch (Exception ignored) {}
        long total = len > 0 ? existing + len : -1;

        if (total > 0) {
            long need = (total - existing) + total; // zip + arquivos extraídos
            if (base.getUsableSpace() < need) {
                con.disconnect();
                throw new IOException("Espaço insuficiente. Libere pelo menos "
                        + fmt(need) + " de armazenamento e tente de novo.");
            }
        }

        long done = existing;
        long lastUi = 0;
        byte[] buf = new byte[64 * 1024];
        try (InputStream in = con.getInputStream();
             FileOutputStream out = new FileOutputStream(part, resume)) {
            int n;
            while ((n = in.read(buf)) > 0) {
                if (cancelled) return false;
                out.write(buf, 0, n);
                done += n;
                long now = System.currentTimeMillis();
                if (now - lastUi > 300) {
                    lastUi = now;
                    l.onProgress("Baixando", total > 0 ? (int) (done * 100 / total) : 0, done, total);
                }
            }
        } finally {
            con.disconnect();
        }
        if (total > 0 && done < total) throw new IOException("A conexão caiu. Toque em JOGAR para continuar de onde parou.");
        l.onProgress("Baixando", 100, done, total);
        return true;
    }

    /** Abre a conexão seguindo redirecionamentos (inclusive http -> https). */
    private HttpURLConnection open(String url, long from) throws IOException {
        for (int i = 0; i < 6; i++) {
            HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
            c.setInstanceFollowRedirects(false);
            c.setConnectTimeout(15000);
            c.setReadTimeout(20000);
            if (from > 0) c.setRequestProperty("Range", "bytes=" + from + "-");
            int code = c.getResponseCode();
            if (code == 301 || code == 302 || code == 303 || code == 307 || code == 308) {
                String loc = c.getHeaderField("Location");
                c.disconnect();
                if (loc == null) throw new IOException("Redirecionamento inválido.");
                url = new URL(new URL(url), loc).toString();
                continue;
            }
            return c;
        }
        throw new IOException("Redirecionamentos demais.");
    }

    // ----------------------------------------------------------------- extrair

    private boolean extract(File base, File zipFile, Listener l) throws IOException {
        String basePath = base.getCanonicalPath() + File.separator;
        ZipFile zf = null;
        try {
            zf = new ZipFile(zipFile);
            long total = 0;
            for (Enumeration<? extends ZipEntry> e = zf.entries(); e.hasMoreElements(); ) {
                ZipEntry z = e.nextElement();
                if (!z.isDirectory() && z.getSize() > 0) total += z.getSize();
            }
            long done = 0;
            int lastPct = -1;
            byte[] buf = new byte[64 * 1024];
            for (Enumeration<? extends ZipEntry> e = zf.entries(); e.hasMoreElements(); ) {
                ZipEntry z = e.nextElement();
                File out = new File(base, z.getName());
                if (!out.getCanonicalPath().startsWith(basePath)) continue; // zip-slip
                if (z.isDirectory()) { out.mkdirs(); continue; }
                File parent = out.getParentFile();
                if (parent != null) parent.mkdirs();
                try (InputStream in = zf.getInputStream(z);
                     FileOutputStream os = new FileOutputStream(out)) {
                    int n;
                    while ((n = in.read(buf)) > 0) {
                        if (cancelled) return false;
                        os.write(buf, 0, n);
                        done += n;
                        int pct = total > 0 ? (int) (done * 100 / total) : 0;
                        if (pct != lastPct) {
                            lastPct = pct;
                            l.onProgress("Instalando", pct, done, total);
                        }
                    }
                }
            }
            return true;
        } catch (java.util.zip.ZipException ex) {
            // zip corrompido: apaga para baixar de novo na próxima vez
            if (zf != null) { try { zf.close(); } catch (IOException ignored) {} zf = null; }
            zipFile.delete();
            throw new IOException("O arquivo do cache veio corrompido. Toque em JOGAR para baixar de novo.");
        } finally {
            if (zf != null) { try { zf.close(); } catch (IOException ignored) {} }
        }
    }

    public static String fmt(long bytes) {
        if (bytes >= 1L << 30) return String.format(java.util.Locale.US, "%.2f GB", bytes / (double) (1L << 30));
        return (bytes >> 20) + " MB";
    }
}
