package com.santosrp.launcher;

import android.app.Activity;
import android.app.Dialog;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Janela de download do cache: círculo de progresso, status e botão cancelar. */
public final class CacheDialog {
    private CacheDialog() {}

    public interface OnFinish { void onInstalled(); }

    public static Dialog show(final Activity a, final OnFinish finish) {
        final float d = a.getResources().getDisplayMetrics().density;
        final Dialog dlg = new Dialog(a);
        dlg.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dlg.setCancelable(false);

        LinearLayout box = new LinearLayout(a);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER_HORIZONTAL);
        box.setPadding((int) (22 * d), (int) (18 * d), (int) (22 * d), (int) (16 * d));
        box.setKeepScreenOn(true);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xF2080808);
        bg.setCornerRadius(16 * d);
        bg.setStroke((int) d, 0x2AFFFFFF);
        box.setBackground(bg);

        TextView title = new TextView(a);
        title.setText("Preparando o jogo");
        title.setTextColor(Color.WHITE);
        title.setTextSize(15);
        title.setTypeface(Typeface.create("sans-serif-black", Typeface.NORMAL));
        box.addView(title);

        final CircleProgressView circle = new CircleProgressView(a);
        box.addView(circle, new LinearLayout.LayoutParams((int) (84 * d), (int) (84 * d)));

        final TextView status = new TextView(a);
        status.setText("Conectando...");
        status.setTextColor(0x99FFFFFF);
        status.setTextSize(12);
        status.setGravity(Gravity.CENTER);
        box.addView(status);

        final TextView btn = new TextView(a);
        btn.setText("CANCELAR");
        btn.setTextColor(0xFFFF4D4D);
        btn.setTextSize(12);
        btn.setTypeface(Typeface.DEFAULT_BOLD);
        btn.setPadding((int) (16 * d), (int) (12 * d), (int) (16 * d), (int) (4 * d));
        box.addView(btn);

        dlg.setContentView(box);
        if (dlg.getWindow() != null) {
            dlg.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
            dlg.getWindow().setLayout((int) (280 * d), ViewGroup.LayoutParams.WRAP_CONTENT);
        }

        final CacheDownloader dl = new CacheDownloader();
        final boolean[] ended = {false};
        dlg.setOnDismissListener(new android.content.DialogInterface.OnDismissListener() {
            @Override public void onDismiss(android.content.DialogInterface di) { dl.cancel(); }
        });

        btn.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                if (ended[0]) { dlg.dismiss(); return; }
                dl.cancel();
                ended[0] = true;
                dlg.dismiss();
            }
        });

        dl.start(a, new CacheDownloader.Listener() {
            @Override public void onProgress(final String fase, final int pct, final long feito, final long total) {
                a.runOnUiThread(new Runnable() { @Override public void run() {
                    if (ended[0]) return;
                    circle.setProgress(pct);
                    status.setText(fase + "  " + CacheDownloader.fmt(feito)
                            + (total > 0 ? " / " + CacheDownloader.fmt(total) : ""));
                }});
            }
            @Override public void onDone() {
                a.runOnUiThread(new Runnable() { @Override public void run() {
                    if (ended[0]) return;
                    ended[0] = true;
                    dlg.dismiss();
                    if (finish != null) finish.onInstalled();
                }});
            }
            @Override public void onError(final String msg) {
                a.runOnUiThread(new Runnable() { @Override public void run() {
                    if (ended[0] && !dlg.isShowing()) return;
                    ended[0] = true;
                    title.setText("Não deu certo");
                    status.setText(msg);
                    btn.setText("FECHAR");
                }});
            }
        });

        dlg.show();
        return dlg;
    }
}
