package com.santosrp.launcher;

import android.app.Activity;
import android.view.View;

import androidx.core.view.DisplayCutoutCompat;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

/** Tela cheia imersiva (sem barras) e conteúdo afastado do notch. */
public final class FullScreen {
    private FullScreen() {}

    @SuppressWarnings("deprecation")
    public static void hideBars(Activity a) {
        a.getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
    }

    /** A foto continua ocupando tudo; só o conteúdo ganha folga do notch. */
    public static void padContentForCutout(View root, final View content) {
        ViewCompat.setOnApplyWindowInsetsListener(root, (v, insets) -> {
            DisplayCutoutCompat c = insets.getDisplayCutout();
            if (c != null) {
                // simétrico: o lado do notch vale para os dois lados, assim os menus
                // da direita ficam à mesma distância da borda que os da esquerda
                int side = Math.max(c.getSafeInsetLeft(), c.getSafeInsetRight());
                content.setPadding(side, c.getSafeInsetTop(), side, c.getSafeInsetBottom());
            }
            return insets;
        });
        ViewCompat.requestApplyInsets(root);
    }
}
