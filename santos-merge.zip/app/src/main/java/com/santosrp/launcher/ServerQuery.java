package com.santosrp.launcher;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;

/** Consulta o servidor pelo protocolo de query do SA-MP/open.mp (UDP). */
public final class ServerQuery {
    private ServerQuery() {}

    /** Retorna {jogadores, máximo} ou null se não respondeu. Chamar fora da thread principal. */
    public static int[] query(String host, int port) {
        if (host == null || host.isEmpty()) return null;
        DatagramSocket socket = null;
        try {
            InetAddress addr = InetAddress.getByName(host);
            byte[] ip = addr.getAddress();
            if (ip.length != 4) return null;
            byte[] req = new byte[11];
            req[0] = 'S'; req[1] = 'A'; req[2] = 'M'; req[3] = 'P';
            System.arraycopy(ip, 0, req, 4, 4);
            req[8] = (byte) (port & 0xFF);
            req[9] = (byte) ((port >> 8) & 0xFF);
            req[10] = 'i';

            socket = new DatagramSocket();
            socket.setSoTimeout(2500);
            socket.send(new DatagramPacket(req, req.length, addr, port));

            byte[] buf = new byte[512];
            DatagramPacket resp = new DatagramPacket(buf, buf.length);
            socket.receive(resp);
            if (resp.getLength() < 14) return null;
            // 11 bytes de eco + 1 byte de senha + 2 bytes jogadores + 2 bytes máximo
            int players = (buf[12] & 0xFF) | ((buf[13] & 0xFF) << 8);
            int max = (buf[14] & 0xFF) | ((buf[15] & 0xFF) << 8);
            return new int[]{players, max};
        } catch (Exception e) {
            return null;
        } finally {
            if (socket != null) socket.close();
        }
    }
}
