package com.santosrp.launcher;

import com.gta.game.R;

import android.animation.ObjectAnimator;
import android.animation.PropertyValuesHolder;
import android.animation.ValueAnimator;
import android.view.View;
import android.view.animation.AccelerateDecelerateInterpolator;

/** Anima o cenário da cidade (skyline em parallax + sol pulsando). */
public final class SceneHelper {
    private SceneHelper() {}

    public static void start(final View root) {
        final View far = root.findViewById(R.id.sceneFar);
        final View near = root.findViewById(R.id.sceneNear);
        View sun = root.findViewById(R.id.sceneSun);

        root.post(new Runnable() {
            @Override
            public void run() {
                pan(far, root.getWidth(), 42000);
                pan(near, root.getWidth(), 26000);
            }
        });

        ObjectAnimator pulse = ObjectAnimator.ofPropertyValuesHolder(sun,
                PropertyValuesHolder.ofFloat("scaleX", 1f, 1.08f),
                PropertyValuesHolder.ofFloat("scaleY", 1f, 1.08f),
                PropertyValuesHolder.ofFloat("alpha", 0.75f, 1f));
        pulse.setDuration(2600);
        pulse.setRepeatCount(ValueAnimator.INFINITE);
        pulse.setRepeatMode(ValueAnimator.REVERSE);
        pulse.start();
    }

    private static void pan(View v, int rootW, long duration) {
        int extra = v.getWidth() - rootW;
        if (extra <= 0) return;
        ObjectAnimator a = ObjectAnimator.ofFloat(v, "translationX", 0f, -extra);
        a.setDuration(duration);
        a.setInterpolator(new AccelerateDecelerateInterpolator());
        a.setRepeatCount(ValueAnimator.INFINITE);
        a.setRepeatMode(ValueAnimator.REVERSE);
        a.start();
    }
}
