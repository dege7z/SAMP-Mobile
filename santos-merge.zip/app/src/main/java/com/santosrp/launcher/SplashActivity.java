package com.santosrp.launcher;

import com.gta.game.R;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;

public class SplashActivity extends BaseActivity {

    private static final String[] TIPS = {
            "Leia as regras antes de entrar na cidade.",
            "Aqui todo mundo é personagem. Respeite o roleplay.",
            "Em Santos, cada escolha tem um preço.",
            "Entre no nosso Discord e fique por dentro das novidades."
    };

    private int lastTip = -1;
    private ValueAnimator loadAnim;
    private boolean finished = false;   // animação terminou
    private boolean launched = false;   // próxima tela já foi aberta
    private boolean resumed = false;

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) FullScreen.hideBars(this);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        startLoading();
    }

    private void startLoading() {
        View logo = findViewById(R.id.logoBox);
        final CircleProgressView circle = (CircleProgressView) findViewById(R.id.loadCircle);
        final TextView tvTip = findViewById(R.id.tvTip);

        logo.setAlpha(0f);
        logo.setScaleX(1.15f);
        logo.setScaleY(1.15f);
        logo.animate().alpha(1f).scaleX(1f).scaleY(1f)
                .setDuration(900).setInterpolator(new DecelerateInterpolator()).start();

        final ValueAnimator va = ValueAnimator.ofInt(0, 100);
        loadAnim = va;
        va.setDuration(3200);
        va.setInterpolator(new AccelerateDecelerateInterpolator());
        va.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator a) {
                int p = (Integer) a.getAnimatedValue();
                circle.setProgress(p);
                int idx = Math.min(TIPS.length - 1, p * TIPS.length / 101);
                if (idx != lastTip) {
                    lastTip = idx;
                    tvTip.setText(TIPS[idx]);
                    tvTip.setAlpha(0f);
                    tvTip.animate().alpha(1f).setDuration(300).start();
                }
            }
        });
        va.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(Animator animation) {
                finished = true;
                // só abre a próxima tela com o app na frente (em segundo plano o Android bloqueia)
                if (resumed) next();
            }
        });
        va.start();
    }

    @Override
    protected void onResume() {
        super.onResume();
        resumed = true;
        if (finished) next();
    }

    @Override
    protected void onPause() {
        resumed = false;
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        // evita a animação continuar e abrir telas depois que a Splash já morreu
        if (loadAnim != null) {
            loadAnim.removeAllListeners();
            loadAnim.removeAllUpdateListeners();
            loadAnim.cancel();
        }
        super.onDestroy();
    }

    private void next() {
        if (launched || isFinishing() || isDestroyed()) return;
        launched = true;
        boolean logged = !Prefs.getNick(this).isEmpty();
        startActivity(new Intent(this, logged ? MainActivity.class : LoginActivity.class));
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
        finish();
    }
}
